/******************************************
*
* Official Name:  Runzhi Ma
*
* Call me:  Runzhi
*
* E-mail:  rma115@syr.edu
*
* Assignment:  final project
*
* Environment/Compiler:  Xcode Version 13.2.1 (13C100)
*
* Date submitted:  April 13, 2022
*
* References: None
*
* Interactions:
*                 Press esc to quit.
*                 Press 0 to view from the top.
*                 Press 1 to view from the north
*                 Press 2 to view from the south
*                 Press 3 to view from the west
*                 Press 4 to view from the east
*                 Press 5 to view from the first person view
*                 Press l or click the black botton on the right side of the wall  to open or close the spot light
*                 Press d or click the door to open or close the door
*                 Press f to open the flash light
*                 Press s to pick up or drop the flash light
*                 Press w or click the wand to make the wand fly and start the ceremony
*                 Press g to choose Gryffindor
*                 Press h to choose Hufflepuff
*                 Press r to choose Ravenclaw
*                 Press n to choose Slytherin
*                 Press + to choose look up
*                 Press - to choose look down
*                 Press GLUT_KEY_UP  to move forward
*                 Press GLUT_KEY_DOWN to move backward
*                 Press GLUT_KEY_RIGHT to turn right
*                 Press GLUT_KEY_LEFT to turn left
*                 Right button to activate the menu; In the menu, you can either quit or activate the light effect of the moon
*******************************************/
#include <cmath>

#include <cstdlib>
#include <iostream>
#include <fstream>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif
#define PI 3.14159265
#include <math.h>
#define ONE_BY_ROOT_THREE 0.57735
using namespace std;
static unsigned int texture[3]; // Array of texture indices.
static float d = 0.0; // Distance parameter in gluLookAt().

static GLUquadricObj *qobj; // Create a pointer to a quadric object.

// Struct of bitmap file.
struct BitMapFile
{
   int sizeX;
   int sizeY;
   unsigned char *data;
};

static float meX=15, meY=2,meZ=0;
//meZ = -8
static float basketballX = 15, basketballY = 2, basketballZ = -2;
static float lookUp = 0;
static float angle=180;  //angle facing
static float stepsize=1.0;  //step size
static float turnsize=5.0;
static float t = 0.0;
using namespace std;
static int scene;
static long font = (long)GLUT_BITMAP_8_BY_13;
bool scenex11WorkAround = true;  //***X11Fix
static int view = 5;
static int width = 500;
static int height = 500;

static bool pickBasketball = true;
static bool shootBall = false;
static float movingBallZ = 0;
static float movingBallY = 0;


static bool ifSun = false;
bool selecting = false;
int xClick,yClick;

// Routine to read a bitmap file.
// Works only for uncompressed bmp files of 24-bit color.
BitMapFile *getBMPData(string filename)
{
   BitMapFile *bmp = new BitMapFile;
   unsigned int size, offset, headerSize;
  
   // Read input file name.
   ifstream infile(filename.c_str(), ios::binary);
 
   // Get the starting point of the image data.
   infile.seekg(10);
   infile.read((char *) &offset, 4);
   
   // Get the header size of the bitmap.
   infile.read((char *) &headerSize,4);

   // Get width and height values in the bitmap header.
   infile.seekg(18);
   infile.read( (char *) &bmp->sizeX, 4);
   infile.read( (char *) &bmp->sizeY, 4);

   // Allocate buffer for the image.
   size = bmp->sizeX * bmp->sizeY * 24;
   bmp->data = new unsigned char[size];

   // Read bitmap data.
   infile.seekg(offset);
   infile.read((char *) bmp->data , size);
   
   // Reverse color from bgr to rgb.
   int temp;
   for (int i = 0; i < size; i += 3)
   {
      temp = bmp->data[i];
      bmp->data[i] = bmp->data[i+2];
      bmp->data[i+2] = temp;
   }

   return bmp;
}


void loadExternalTextures()
{
   // Local storage for bmp image data.
   BitMapFile *image[3];

   // Load the textures.
   image[0] = getBMPData("grass.bmp");
   image[1] = getBMPData("court.bmp");
   image[2] = getBMPData("basketball.bmp");
   
   // Bind grass image to texture index[0].
   glBindTexture(GL_TEXTURE_2D, texture[0]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[0]->sizeX, image[0]->sizeY, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image[0]->data);

   // Bind sky image to texture index[1]
   glBindTexture(GL_TEXTURE_2D, texture[1]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[1]->sizeX, image[1]->sizeY, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image[1]->data);
    
   // Bind sky image to texture index[2]
   glBindTexture(GL_TEXTURE_2D, texture[2]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[1]->sizeX, image[1]->sizeY, 0,
                 GL_RGB, GL_UNSIGNED_BYTE, image[1]->data);
}



void writeBitmapString(void *font, const char *string)
{
   const char *c;
   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

void setProjection()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(-10.0, 10.0, -10.0, 10.0, 1.0, 21.0);
    
    glFrustum(-2,2,-2,2,1,25);
    //glOrtho(0, 50, 0, 50, 1, 120);
    
    //gluPerspective(80, 1, 1, 21);
    
    glMatrixMode(GL_MODELVIEW);
   
}

void drawGround(void){
//    glColor3f(157.0/255, 110.0/255, 94.0/255);
//    glPushMatrix();
//    glTranslated(15,-.5,-10);
//    glScaled(30, 1, 20);
//    glutSolidCube(1);
//    glPopMatrix();
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
    glBegin(GL_POLYGON);
       glTexCoord2f(0.0, 0.0); glVertex3f(0, 0, 0);
       glTexCoord2f(8.0, 0.0); glVertex3f(30, 0.0, 0);
       glTexCoord2f(8.0, 8.0); glVertex3f(30, 0, -20);
       glTexCoord2f(0.0, 8.0); glVertex3f(0, 0, -20);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

void drawCourt(void){
    // Map the sky texture onto a rectangle parallel to the xy-plane.
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[1]);
    glBegin(GL_POLYGON);
       glTexCoord2f(0.0, 0.0); glVertex3f(22, 0.1, -17);
       glTexCoord2f(1.0, 0.0); glVertex3f(22, 0.1, -8);
       glTexCoord2f(1.0, 1.0); glVertex3f(27, 0.1, -8);
       glTexCoord2f(0.0, 1.0); glVertex3f(27, 0.1, -17);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}


void drawChair(float x, float y, float z){
    glPushMatrix();
        glTranslatef(x, y, z);
        
        glPushMatrix();
            glTranslatef(0, 0.5, 0);
            glRotatef(90, 1, 0, 0);
            glutSolidTorus(0.1, 0.1, 50, 50);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 0.25, 0);
            glScalef(0.2, 0.5, 0.2);
            glutSolidCube(1);
        glPopMatrix();
    glPopMatrix();
}



void drawTable(float x, float y, float z) {
    float matAmbAndDif0[] = {171.0/255, 92.0/255, 224.0/255, 1.0};
    float matAmbAndDif1[] = {242.0/255, 170.0/255, 69.0/255, 1.0};
    float matAmbAndDif2[] = {111.0/255, 71.0/255, 59.0/255, 1.0};
    float matAmbAndDifCup[] = {148.0/255, 182.0/255, 165.0/255, 1.0};
    float matAmbAndDifHolder[] = {189.0/255, 150.0/255, 115.0/255, 1.0};
    
 
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    
    glPushMatrix();
        glTranslatef(x, y, z);

        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif1);
        glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
        glColor3f(0.5, 0.4, 0.2);
//        glEnable(GL_TEXTURE_2D);
//        glBindTexture(GL_TEXTURE_2D, texture[2]);
        glPushMatrix();
            glTranslatef(0, 1, 0);
            glScalef(1, 0.1, 1);
            glutSolidCube(1);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 1/2.0, 0);
            glScalef(1/5.0, 1, 1/5.0);
            glutSolidCube(1);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 0.1/4, 0);
            glScalef(1/2.0, 0.1/2, 1/2.0);
            glutSolidCube(1);
        glPopMatrix();
//        glDisable(GL_TEXTURE_2D);
    
        //chair
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif0);
        glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
        glColor3f(0.2, 0.6, 0.3);
        drawChair(0, 0, 0.7);
        drawChair(0, 0, -0.7);
        drawChair(0.7, 0, 0);
        drawChair(-0.7, 0, 0);
    
        glPushMatrix();
            glTranslatef(0, 1.2, 0);
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glutSolidTeapot(0.2);
   
            //The Holder
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifHolder);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glPushMatrix();
                glTranslatef(0, 0.2, 0.3);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.1, 0.5, 20, 20);
            glPopMatrix();
    
            //The cup
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifCup);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glPushMatrix();
                glTranslatef(-0.3, 0.05, 0.15);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.05, 0.2, 20, 20);
            glPopMatrix();
    
            glPushMatrix();
                glTranslatef(-0.3, 0.05, -0.15);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.05, 0.2, 20, 20);
            glPopMatrix();
        glPopMatrix();
        
        
    glPopMatrix();
    
    

//    float leg_x = length / 2.0 - width / 2.;
//    float leg_z = depth / 2.0 - width / 2.;
//
//    glPushMatrix();
//    glTranslatef(-leg_x, height / 2.0, leg_z);
//    glScalef(width, height, width);
//    glutSolidCube(1);
//    glPopMatrix();
//    glPushMatrix();
//    glTranslatef(leg_x, height / 2.0, -leg_z);
//    glScalef(width, height, width);
//    glutSolidCube(1);
//    glPopMatrix();
//    glPushMatrix();
//    glTranslatef(-leg_x, height / 2.0, -leg_z);
//    glScalef(width, height, width);
//    glutSolidCube(1);
//    glPopMatrix();
//    glPushMatrix();
//    glTranslatef(leg_x, height / 2.0, leg_z);
//    glScalef(width, height, width);
//    glutSolidCube(1);
//    glPopMatrix();
}

void setup(void){
    //dark blue background
    glClearColor(0, 0, 139.0/255, 0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    
    
    // Create the new quadric object.
    qobj = gluNewQuadric();

    // Specify that quadrics are drawn in wireframe.
    gluQuadricDrawStyle(qobj, GLU_LINE);
    
    // Create texture index array.
    glGenTextures(3, texture);

    // Load external textures.
    loadExternalTextures();

    // Turn on OpenGL texturing.
    glEnable(GL_TEXTURE_2D);

    // Specify how texture values combine with current surface color values.
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    float lightAmb[] = { 0.0, 0.0, 0.0, 1.0 };
    float lightDifAndSpec[] = { 1.0, 1.0, 1.0, 1.0 };
    float lightPos[] = { 15, 1.5, -10.0, 1.0 };
    float globAmb[] = { 0.2, 0.2, 0.2, 1.0 };
    
    // Light properties.

    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDifAndSpec);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightDifAndSpec);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    
    glEnable(GL_LIGHT0); // Enable particular light source.
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globAmb); // Global ambient light.
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE); // Enable two-sided lighting.
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE); // Enable local viewpoint.
    glEnable(GL_NORMALIZE);

}


void resize(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60,(float)w/(float)h,1,20);
    glMatrixMode(GL_MODELVIEW);
    
}


void writeStrokeString(void *font, const char *string)
{
    const char *c;
    for (c = string; *c != '\0'; c++) glutStrokeCharacter(font, *c);
}

void getID(int x, int y)
{
    unsigned char pixel[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
    //printed only for demonstration
    cout << "R: " << (int)pixel[0] << endl;
    cout << "G: " << (int)pixel[1] << endl;
    cout << "B: " << (int)pixel[2] << endl;
    cout << endl;
    
    if((int)pixel[0]>=65.0&&(int)pixel[0]<=75&&(int)pixel[1]>=45&&(int)pixel[1]<=55
       &&(int)pixel[2]>=40&&(int)pixel[2]<=50)
    {

    }
//    else if ((int)pixel[0]==38&&(int)pixel[1]==35&&(int)pixel[2]==30)
//    {
//        openDoor = !openDoor;  //two for blue, cone
//    }
//    else if ((int)pixel[0]==(int)pixel[1] && (int)pixel[1]==(int)pixel[2])
//    {
//        openSpotLight = !openSpotLight;  //two for blue, cone
//    }
    
    selecting=false;
    glutPostRedisplay();
}



void mouseControl(int button, int state, int x, int y)
{
    if(state==GLUT_DOWN && button == GLUT_LEFT)
    {   selecting=true;
        xClick=x;
        yClick=height-y; //for screen vs mouse coordinates
        glutPostRedisplay();
       
    }
}


void lookAt(){
    if(view == 0){
        //From top
        gluLookAt(15, 15, -10,
                  15,5,-10,
                  0,0,1);
    }
    else if(view == 1){
        //view from the north
        gluLookAt(15, 5, -28,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 2){
        //view from the south
        gluLookAt(15, 5, 8,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 3){
        //view from the west
        gluLookAt(-6, 5, -10,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 4){
        //view from the east
        gluLookAt(36, 5, -10,
                  15,5,-10,
                  0,1,0);
    }
    else{
        gluLookAt(meX, meY, meZ, meX + sin(angle * PI / 180) , meY + lookUp, meZ + cos(angle * PI / 180), 0, 1, 0);
    }
}

void drawTree(float x, float z){
    float matAmbAndDif1[] = {134.0/255, 68.0/255, 57.0/255, 1.0};
    float matAmbAndDif2[] = {100.0/255, 230.0/255, 150.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    
    
    glPushMatrix();
    glTranslatef(x, 0, z);
    //root
    glPushMatrix();
    glTranslatef(0,1.5,0);
    glScalef(.5, 3, .5);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif1);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glutSolidCube(1);
    glPopMatrix();
    
    //Leaves
    glPushMatrix();
    glTranslatef(0,3,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(1.5, 1.5, 20, 20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,4,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(1, 1.5, 20, 20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,5,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(0.5, 1.5, 20, 20);
    glPopMatrix();
    
    glPopMatrix();
}

void drawBasketry(float x, float y, float z, float angle){
    float matAmbAndDifPole[] = {28.0/255, 26.0/255, 27.0/255, 1.0};
    float matAmbAndDifBoard[] = {229.0/255, 236.0/255, 242.0/255, 1.0};
    float matAmbAndDifBasketAndSquare[] = {232.0/255, 50.0/255, 45.0/255, 1.0};
    float matAmbAndDifNet[] = {203.0/255, 192.0/255, 189.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(angle, 0, 1, 0);
        
        //The pole
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifPole);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            //First Arm
            glPushMatrix();
                glTranslatef(0, 1.25, 0);
                glScalef(0.2, 2.5, 0.2);
                glutSolidCube(1);
            glPopMatrix();
    
            //Second Arm
            glPushMatrix();
                glTranslatef(0, 1.5, -0.17);
                glRotatef(30, 1, 0, 0);
                glTranslatef(0, 1, 0);
                glScalef(0.2, 1.5, 0.2);
                glutSolidCube(1);
            glPopMatrix();
        glPopMatrix();
    
        //The Board
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBoard);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
    
            glTranslatef(0, 3, 0.75);
            glScalef(2, 1.5, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        //The Red Square
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBasketAndSquare);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glColor3f(1,0,0);
            glTranslatef(0, 2.7, 0.76);
            glScalef(2/3.0, 0.5, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBoard);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);

            glTranslatef(0, 2.7, 0.77);
            glScalef(2/3.0 - 0.1, 0.5 - 0.1, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        //The basket
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBasketAndSquare);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glColor3f(1,0,0);
            glTranslatef(0, 2.5, 1.12);
            glRotatef(90,1,0,0);
            glutSolidTorus(0.02, 0.35, 100, 100);
        glPopMatrix();
    
        //The net
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifNet);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glTranslatef(0, 2.5, 1.12);
            glRotatef(90, 1, 0, 0);
            gluCylinder(qobj, 0.35, 0.25, 0.3, 20, 10);
        glPopMatrix();
        
    glPopMatrix();
    
    
}

void drawStair(float x, float y, float z){
    glPushMatrix();
    glTranslatef(x,y,z);
        glPushMatrix();
            glTranslatef(0, 2.3, 1.3);
            glScalef(1.8,0.1,0.4);
            glutSolidCube(1);
        glPopMatrix();
    
        glPushMatrix();
            glTranslatef(0, 2.15, 1.55);
            glRotatef(90, 1, 0, 0);
            glScalef(1.8,0.1,0.4);
            glutSolidCube(1);
        glPopMatrix();
    glPopMatrix();
}

void drawSlide(float x, float y, float z){
    float matAmbAndDifSlide[] = {197.0/255, 9.0/255, 20.0/255, 1.0};
    float matAmbAndDifPole[] = {34.0/255, 217.0/255, 245.0/255, 1.0};
    float matAmbAndDifStairAndTop[] = {217.0/255, 165.0/255, 25.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(90, 0, 1, 0);
    
        //The Pole
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifPole);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);

        for(int i = -1; i<= 1; i+=2){
            for(int j = -1; j<= 1; j+=2){
                glPushMatrix();
                glTranslatef(i, 2, j);
                glScalef(0.2, 4, 0.2);
                glutSolidCube(1);
                glPopMatrix();
            }
        }
    
        //The Roof
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifStairAndTop);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 4, 0);
            glRotatef(90, -1, 0, 0);
            glutSolidCone(1.4, 0.8, 50, 50);
        glPopMatrix();
    
        //Floor
        glPushMatrix();
            glTranslatef(0, 2.3, 0);
            glScalef(2,0.2,2);
            glutSolidCube(1);
        glPopMatrix();
    
        //Stairs
        drawStair(0,0,0);
        drawStair(0,-0.4,0.5);
        drawStair(0,-0.8,1.0);
        drawStair(0,-1.2,1.5);
        drawStair(0,-1.6,2.0);
        drawStair(0,-2,2.5);
        drawStair(0,-2.4,3.0);
        
        //Slides
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifSlide);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 1.1, -3);
            glRotatef(-30, 1, 0, 0);
            glScalef(1.8,0.1,5);
            glutSolidCube(1);
        glPopMatrix();
    

            
            
    glPopMatrix();
}

void drawBasketball(void){
    glPushMatrix();
//        glTranslatef(basketballX, basketballY, basketballZ);
//        glTranslatef(meX, meY, meZ -1);
//    basketballX = meX + (movingBallZ + 1) * sin((180.0-angle) * PI / 180)/2;
//    basketballY = meY + (-11.0/48)*movingBallZ*movingBallZ + (25.0/24)*movingBallZ;
//    basketballZ = meZ - (movingBallZ+1) * cos((180.0- angle) * PI / 180)/2;
        if(pickBasketball){
            if(shootBall){
                glTranslatef(basketballX  , basketballY - movingBallY, basketballZ - 1);
                glTranslatef(0,0,1);
                glRotatef(angle -180, 0 , 1, 0);
                glTranslatef(0,+ (-11.0/48)*movingBallZ*movingBallZ + (25.0/24)*movingBallZ
                             ,- movingBallZ);
                glTranslatef(0,0,-1);
            }
            else{
                glTranslatef(meX  , meY, meZ - 1);
                glTranslatef(0,0,1);
                glRotatef(angle -180, 0 , 1, 0);
//                glTranslatef(0,+ (-11.0/48)*movingBallZ*movingBallZ + (25.0/24)*movingBallZ,- movingBallZ);
                glTranslatef(0,0,-1);
            }
        }
        else{
            glTranslatef(24.5, 0.3, -12.5);
        }
    
    
        glutSolidSphere(0.3, 50, 50);
    glPopMatrix();
}

void drawScene(void){
    // *********  x11Fix begin chunk
    if(scenex11WorkAround)
    {
        glutReshapeWindow(width-1,height-1);// Has to be different dimensions than in glutInitWindowSize();
        scenex11WorkAround = false;
    }
    //*********** x11Fix end chunk
    
    // Material property vectors.
    float lightPos0[] = { 0,0,0, 1.0 };
//    float lightPos1[] = { meX , meY - 1, meZ - 1, 1.0 };
//    float matAmbAndDif1[] = {191.0/255, 177.0/255,
    
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    float matShine1[] = {1.0};
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
//    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, t);
    glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, t);
    
    //Set Projection
    setProjection();
    
    //Clear Modeview Matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    lookAt();
    glDisable(GL_LIGHTING);
    
    // make a sun
    glDisable(GL_LIGHTING);
    
    glLightfv(GL_LIGHT0, GL_SPECULAR, matSpec);
    glLightfv(GL_LIGHT0, GL_SHININESS, matShine1);

    if(!ifSun){
        glDisable(GL_LIGHT0);
    }else{
        //printf("%f-%f\n",camX,camZ);
        glEnable(GL_LIGHT0);
    }
    glPushMatrix();
    glTranslatef(27, 11, -15);
    glColor3f(1.0, 1.0, 1.0);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);
    glutSolidSphere(2, 8, 8);
    glPopMatrix();
    glEnable(GL_LIGHTING);
    
        
    
    

    //Draw the ground
    drawGround();
    
    drawCourt();
        
    drawTable(26, 0, -2);
    drawTable(22, 0, -4);
    drawTable(24, 0, -6);
    
    drawBasketry(24.5, 0, -17, 0);
    
    drawBasketry(24.5, 0, -8, 180);

//    drawSky();
    
    //Draww trees
    for(int i = -1.5 ; i >= -20; i-=3){
        drawTree(28.5,i);
    }
    
    for(int i = -1.5 ; i >= -20; i-=3){
        drawTree(1.5,i);
    }
    
    for(int i = 4.5 ; i <= 25.5; i+=3){
        drawTree(i,-18.5);
    }
    
    drawBasketball();
    
    drawSlide(10,0,-15);

    

    
    
    
    if(selecting) getID(xClick, yClick);
    
    
    

    
    
    glutSwapBuffers();
    
    
}



void animate(int f){
    //篮球投射
    if(shootBall && movingBallZ < 4){
//        printf("BasketballX = %f\n", basketballX);
//        printf("BasketballY = %f\n", basketballY);
//        printf("BasketballZ = %f\n", basketballZ);
//        printf("MeX = %f\n", meX);
//        printf("MeY = %f\n", meY);
//        printf("MeZ = %f\n", meZ);
        movingBallZ += 0.1;
    }
    
    if((movingBallZ > 4 && movingBallZ < 4.1 )& (basketballX > 24.2 && basketballX < 24.9) & ((basketballZ > -15 && basketballZ < -13.3) || (basketballZ > -11.9 && basketballZ < -11.1))&& (basketballY - movingBallY > 0)){
        printf("Bingo!\n");
        movingBallY += 0.1;
    }
    
    
    
    
//    else movingBallZ += 0.1;
    
//    if(meY - (-11.0/48)*movingBallZ*movingBallZ + (25.0/24)*movingBallZ == 0){
//        shootBall = false;
//    }
//    else{
//        movingBallZ = 0;
//        shootBall = !shootBall;
//    }
    
    //location of far basket BasketballX = 24.426397
//    BasketballY = 2.418543
//    BasketballZ = -13.621511
    //location of near basket
//    Angle - 180 = 180.000000
//    BasketballX = 24.426397
//    BasketballY = 2.418543
//    BasketballZ = -11.521513
//
    
    glutPostRedisplay();
    glutTimerFunc(20, animate, 0);
}


void keyInput(unsigned char key, int x, int y)
{
   switch(key)
   {
       case 27:
           exit(0);
           break;
       case '0':
           view = 0;
           glutPostRedisplay();
           break;
       case'1':
           view = 1;
           glutPostRedisplay();
           break;
       case'2':
           view = 2;
           glutPostRedisplay();
           break;
       case'3':
           view = 3;
           glutPostRedisplay();
           break;
       case'4':
           view = 4;
           glutPostRedisplay();
           break;
       case'5':
           view = 5;
           glutPostRedisplay();
           break;
       case's':
           ifSun = !ifSun;
           glutPostRedisplay();
           break;
       case'p':
           pickBasketball = !pickBasketball;
//           printf("MeX = %f\n", meX);
//           printf("MeY = %f\n", meY);
//           printf("MeZ = %f\n", meZ);
           glutPostRedisplay();
           break;
       case'f':
           shootBall = !shootBall;
           basketballX = meX;
           basketballY = meY;
           basketballZ = meZ;
           glutPostRedisplay();
           break;
       case'l':
           printf("Angle - 180 = %f\n", (angle - 180));
           printf("BasketballX = %f\n", basketballX);
           printf("BasketballY = %f\n", basketballY);
           printf("BasketballZ = %f\n", basketballZ);
           printf("MovingBallZ = %f\n", movingBallZ);
           glutPostRedisplay();
           break;

     
   }
}

void specialKeyInput(int key, int x, int y)
{
    switch(key){
        case GLUT_KEY_UP: //forward
            meZ += stepsize * cos(angle * PI / 180)/2;
            meX += stepsize * sin(angle * PI / 180)/2;
//            glutPostRedisplay();
            break;
        case GLUT_KEY_DOWN: //back
            meZ -= stepsize * cos(angle * PI / 180)/2;
            meX -= stepsize * sin(angle * PI / 180)/2;
            break;
        case GLUT_KEY_RIGHT: //turn right
            angle -= turnsize;
            break;
        case GLUT_KEY_LEFT: //turn left
            angle += turnsize;
            break;
    }//end switch
    glutPostRedisplay();
}
void menu(int id){
    if(id == 1) exit(0);

    glutPostRedisplay();
}

void makeMenu(void){
    glutCreateMenu(menu);

    glutAddMenuEntry("Quit", 1);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
    
}


int main(int argc, char **argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Sorting Hat");
    setup();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyInput);
    glutMouseFunc(mouseControl);
    glutSpecialFunc(specialKeyInput);
    glutTimerFunc(20, animate, 0);
    makeMenu();

    
    
    glutMainLoop();

    return 0;
}
