/******************************************
*
* Official Name:  Runzhi Ma
*
* Call me:  Runzhi
*
* E-mail:  rma115@syr.edu
*
* Assignment:  final project
*
* Environment/Compiler:  Xcode Version 13.2.1 (13C100)
*
* Date submitted:  April 30, 2022
*
* References: I have use some functions like printing string, import texture from professor's code from the class.
*
* Interactions:
*                 Press esc to quit.
*                 Press 0 to view from the top.
*                 Press 1 to view from the north
*                 Press 2 to view from the south
*                 Press 3 to view from the west
*                 Press 4 to view from the east
*                 Press 5 to view from the first person view
*                 Press s to activate of deactivate the sun
*                 Press p to shoot the basketball
*                 Press c to make the park carouse move or stop
*                 Press m to make the cloud move or stop
*                 Press b to make the bee move or stop
*                 Press w to activate the welcome words or deactivate it
*                 Press + to choose look up
*                 Press - to choose look down
*                 Press r to start or stop the rain
*                 Press h to rain
*                 Press j to snow
*                 Press GLUT_KEY_UP  to move forward
*                 Press GLUT_KEY_DOWN to move backward
*                 Press GLUT_KEY_RIGHT to turn right
*                 Press GLUT_KEY_LEFT to turn left
*                 Right button to activate the menu; In the menu, you can almost all the thing you can do same as using keyboard
*******************************************/
#include <cmath>
#include <string.h>
#include <cstdlib>
#include <iostream>
#include <fstream>
#define TRUE 1
#define FALSE 0
#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif
#define PI 3.14159265
#include <math.h>
#define MAX_NUM_PARTICLES 1000
using namespace std;
static int main_window, display_window; //Name of different menu
static unsigned int texture[3]; // Array of texture indices.
static float d = 0.0; // Distance parameter in gluLookAt().
int num_particles = 40; //Number of rain objecrt
static GLUquadricObj *qobj; // Create a pointer to a quadric object.
GLuint startList;
typedef struct particle
{
     int color;
     float position[3];
//     float velocity[3];
//     float mass;
} particle;

particle particles[MAX_NUM_PARTICLES];

GLfloat colors[8][3]={{34.0/255, 201.0/255, 255.0/255}};

// Struct of bitmap file.
struct BitMapFile
{
   int sizeX;
   int sizeY;
   unsigned char *data;
};

static float meX=15, meY=2,meZ=0;
//meZ = -8
static float basketballX = 15, basketballY = 2, basketballZ = -2;
static float lookUp = 0;
static float angle=180;  //angle facing
static float stepsize=1.0;  //step size
static float turnsize=5.0;
static float t = 0.0;
using namespace std;
static int scene;
static long font = (long)GLUT_BITMAP_8_BY_13;
bool scenex11WorkAround = true;  //***X11Fix
bool displayx11WorkAround = true;
static int view = 5;
static int width = 500;
static int height = 500;
static bool cloudMove = false;
static bool ifWelcome = true;
static bool ifRain = false;
static float rainSpeed = 0.5;
static float rainShape = 1;
static float beesAngle = 0;
static float wingsAngle = 0;
static bool beessFly = false;
static bool pickBasketball = false;
static bool shootBall = false;
static float movingBallZ = 0;
static float movingBallY = 0;
static float ballAngle = 0;
static float rotateAngle = 0;
static int pointsCount = 0;
static bool ifParkCarouse = false;
static float parkCarouselAngle = 0;
static float cloud1 = 15;
static float cloud2 = 10;
static float cloud3 = 19;
static float cloud4 = 15;
static float cloud5 = 20;
static float cloud6 = 7;
static float cloud7 = 3;
static bool ifSun = false;
bool selecting = false;
int xClick,yClick;


BitMapFile *getBMPData(string filename)
{
   BitMapFile *bmp = new BitMapFile;
   unsigned int size, offset, headerSize;
   // Read input file name.
   ifstream infile(filename.c_str(), ios::binary);
   // Get the starting point of the image data.
   infile.seekg(10);
   infile.read((char *) &offset, 4);
   // Get the header size of the bitmap.
   infile.read((char *) &headerSize,4);
   infile.seekg(18);
   infile.read( (char *) &bmp->sizeX, 4);
   infile.read( (char *) &bmp->sizeY, 4);
   // Allocate buffer for the image.
   size = bmp->sizeX * bmp->sizeY * 24;
   bmp->data = new unsigned char[size];
   // Read bitmap data.
   infile.seekg(offset);
   infile.read((char *) bmp->data , size);
   // Reverse color from bgr to rgb.
   int temp;
   for (int i = 0; i < size; i += 3)
   {
      temp = bmp->data[i];
      bmp->data[i] = bmp->data[i+2];
      bmp->data[i+2] = temp;
   }
   return bmp;
}


void loadExternalTextures()
{
   // Local storage for bmp image data.
   BitMapFile *image[3];

   // Load the textures.
   image[0] = getBMPData("rma115TEXTURES/grass.bmp");
   image[1] = getBMPData("rma115TEXTURES/court.bmp");
   image[2] = getBMPData("rma115TEXTURES/basketball.bmp");
   
   // Bind grass image to texture index[0].
   glBindTexture(GL_TEXTURE_2D, texture[0]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[0]->sizeX, image[0]->sizeY, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image[0]->data);

   // Bind sky image to texture index[1]
   glBindTexture(GL_TEXTURE_2D, texture[1]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[1]->sizeX, image[1]->sizeY, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image[1]->data);
    
   // Bind basketball image to texture index[2]
   glBindTexture(GL_TEXTURE_2D, texture[2]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image[2]->sizeX, image[2]->sizeY, 0,
                 GL_RGB, GL_UNSIGNED_BYTE, image[2]->data);
}



void writeBitmapString(void *font, const char *string)
{
   const char *c;
   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}

void setProjection()
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-2,2,-2,2,1,25);
    glMatrixMode(GL_MODELVIEW);
   
}

void drawGround(void){
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
    glBegin(GL_POLYGON);
       glTexCoord2f(0.0, 0.0); glVertex3f(0, 0, 0);
       glTexCoord2f(8.0, 0.0); glVertex3f(30, 0.0, 0);
       glTexCoord2f(8.0, 8.0); glVertex3f(30, 0, -20);
       glTexCoord2f(0.0, 8.0); glVertex3f(0, 0, -20);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

void drawCourt(void){
    // Map the sky texture onto a rectangle parallel to the xy-plane.
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[1]);
    glBegin(GL_POLYGON);
       glTexCoord2f(0.0, 0.0); glVertex3f(22, 0.1, -17);
       glTexCoord2f(1.0, 0.0); glVertex3f(22, 0.1, -8);
       glTexCoord2f(1.0, 1.0); glVertex3f(27, 0.1, -8);
       glTexCoord2f(0.0, 1.0); glVertex3f(27, 0.1, -17);
    glEnd();
    glDisable(GL_TEXTURE_2D);
}

void drawChair(float x, float y, float z){
    glPushMatrix();
        glTranslatef(x, y, z);
        
        glPushMatrix();
            glTranslatef(0, 0.5, 0);
            glRotatef(90, 1, 0, 0);
            glutSolidTorus(0.1, 0.1, 50, 50);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 0.25, 0);
            glScalef(0.2, 0.5, 0.2);
            glutSolidCube(1);
        glPopMatrix();
    glPopMatrix();
}

void drawTable(float x, float y, float z) {
    float matAmbAndDif0[] = {171.0/255, 92.0/255, 224.0/255, 1.0};
    float matAmbAndDif1[] = {242.0/255, 170.0/255, 69.0/255, 1.0};
    float matAmbAndDif2[] = {111.0/255, 71.0/255, 59.0/255, 1.0};
    float matAmbAndDifCup[] = {148.0/255, 182.0/255, 165.0/255, 1.0};
    float matAmbAndDifHolder[] = {189.0/255, 150.0/255, 115.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    
    glPushMatrix();
        glTranslatef(x, y, z);

        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif1);
        glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
        glColor3f(0.5, 0.4, 0.2);
        glPushMatrix();
            glTranslatef(0, 1, 0);
            glScalef(1, 0.1, 1);
            glutSolidCube(1);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 1/2.0, 0);
            glScalef(1/5.0, 1, 1/5.0);
            glutSolidCube(1);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(0, 0.1/4, 0);
            glScalef(1/2.0, 0.1/2, 1/2.0);
            glutSolidCube(1);
        glPopMatrix();
    
        //chair
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif0);
        glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
        glColor3f(0.2, 0.6, 0.3);
        drawChair(0, 0, 0.7);
        drawChair(0, 0, -0.7);
        drawChair(0.7, 0, 0);
        drawChair(-0.7, 0, 0);
    
        glPushMatrix();
            glTranslatef(0, 1.2, 0);
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glutSolidTeapot(0.2);
   
            //The Holder
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifHolder);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glPushMatrix();
                glTranslatef(0, 0.2, 0.3);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.1, 0.5, 20, 20);
            glPopMatrix();
    
            //The cup
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifCup);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glPushMatrix();
                glTranslatef(-0.3, 0.05, 0.15);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.05, 0.2, 20, 20);
            glPopMatrix();
    
            glPushMatrix();
                glTranslatef(-0.3, 0.05, -0.15);
                glRotatef(90, 1, 0, 0);
                gluCylinder(qobj, 0.1, 0.05, 0.2, 20, 20);
            glPopMatrix();
        glPopMatrix();
        
        
    glPopMatrix();
}

void setupDisplayWindow(void){
    //black background
    glClearColor(0,0,0,0);


}

void setup(void){
    //dark blue background
    glClearColor(0, 0, 139.0/255, 0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    
    
    // Create the new quadric object.
    qobj = gluNewQuadric();

    // Specify that quadrics are drawn in wireframe.
    gluQuadricDrawStyle(qobj, GLU_LINE);
    
    // Create texture index array.
    glGenTextures(3, texture);

    // Load external textures.
    loadExternalTextures();

    // Turn on OpenGL texturing.
    glEnable(GL_TEXTURE_2D);

    // Specify how texture values combine with current surface color values.
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    float lightAmb[] = { 0.0, 0.0, 0.0, 1.0 };
    float lightDifAndSpec[] = { 1.0, 1.0, 1.0, 1.0 };
    float lightPos[] = { 15, 1.5, -10.0, 1.0 };
    float globAmb[] = { 0.2, 0.2, 0.2, 1.0 };
    
    // Light properties.

    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDifAndSpec);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightDifAndSpec);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    
    glEnable(GL_LIGHT0); // Enable particular light source.
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globAmb); // Global ambient light.
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE); // Enable two-sided lighting.
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE); // Enable local viewpoint.
    glEnable(GL_NORMALIZE);
    
    /* Create 4 display lists, each with a different quadric object.
     * Different drawing styles and surface normal specifications
     * are demonstrated.
     */
    startList = glGenLists(1);
    qobj = gluNewQuadric();
    //gluQuadricCallback(qobj, GLU_ERROR, errorCallback);
    
    gluQuadricDrawStyle(qobj, GLU_FILL); /* smooth shaded */
    gluQuadricNormals(qobj, GLU_SMOOTH);
    gluQuadricTexture(qobj,true);
    glNewList(startList, GL_COMPILE);
    gluSphere(qobj, 0.3, 50, 50);
    glEndList();


}

void myinit()
{
        int  i, j;
        for(i=0; i<num_particles; i++)
        {
            particles[i].color = 0;
            //x
            particles[i].position[0] = 30.0*((float) rand()/RAND_MAX);
            //y
            particles[i].position[1] = 7.5*((float) rand()/RAND_MAX);
            //z
            particles[i].position[2] = -20.0*((float) rand()/RAND_MAX);
        }
}


void resize(int w, int h)
{
    
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60,(float)w/(float)h,1,20);
    glMatrixMode(GL_MODELVIEW);
    
}

void writeStrokeString(void *font, const char *string)
{
    const char *c;
    for (c = string; *c != '\0'; c++) glutStrokeCharacter(font, *c);
}

void getID(int x, int y)
{
    unsigned char pixel[3];
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, pixel);
    //printed only for demonstration
    cout << "R: " << (int)pixel[0] << endl;
    cout << "G: " << (int)pixel[1] << endl;
    cout << "B: " << (int)pixel[2] << endl;
    cout << endl;
    
    if((int)pixel[0]>=135.0&&(int)pixel[0]<=149&&(int)pixel[1]>=14&&(int)pixel[1]<=14
       &&(int)pixel[2]>=21&&(int)pixel[2]<=21)
    {
        ifParkCarouse = ! ifParkCarouse;
    }
    else if ((int)pixel[0]==40&&(int)pixel[1]==4&&(int)pixel[2]==6)
    {
        ifParkCarouse = ! ifParkCarouse;
    }
    else if ((int)pixel[0]==48&&(int)pixel[1]==36&&(int)pixel[2]==6)
    {
        beessFly = !beessFly;
    }
    else if ((int)pixel[0]==51&&(int)pixel[1]==51&&(int)pixel[2]==51)
    {
        cloudMove = !cloudMove;
    }

    selecting=false;
    glutPostRedisplay();
}



void mouseControl(int button, int state, int x, int y)
{
    if(state==GLUT_DOWN && button == GLUT_LEFT)
    {   selecting=true;
        xClick=x;
        yClick=height-y; //for screen vs mouse coordinates
        glutPostRedisplay();
       
    }
}


void lookAt(){
    if(view == 0){
        //From top
        gluLookAt(15, 15, -10,
                  15,5,-10,
                  0,0,1);
    }
    else if(view == 1){
        //view from the north
        gluLookAt(15, 5, -28,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 2){
        //view from the south
        gluLookAt(15, 5, 8,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 3){
        //view from the west
        gluLookAt(-6, 5, -10,
                  15,5,-10,
                  0,1,0);
    }
    else if(view == 4){
        //view from the east
        gluLookAt(36, 5, -10,
                  15,5,-10,
                  0,1,0);
    }
    else{
        gluLookAt(meX, meY, meZ, meX + sin(angle * PI / 180) , meY + lookUp, meZ + cos(angle * PI / 180), 0, 1, 0);
    }
}

void drawCloud(float x, float y, float z){
    float matAmbAndDifCloud[] = {255.0/255, 255.0/255, 255.0/255, 1.0};
    float matAmbAndDifStairAndTop[] = {217.0/255, 165.0/255, 25.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifCloud);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matAmbAndDifCloud);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
    
    glPushMatrix();
        glTranslatef(x, y, z);
        
        //Middle Cloud
        glColor3f(1,1,1);
        glPushMatrix();
            glScalef(1.5, 1, 1);
            glutSolidSphere(1, 50,50);
        glPopMatrix();
    
        glPushMatrix();
            glTranslatef(-1.9, 0, 0);
            glScalef(1, 0.8, 0.8);
            glutSolidSphere(1, 50,50);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(1.9, 0, 0);
            glScalef(1, 0.8, 0.8);
            glutSolidSphere(1, 50,50);
        glPopMatrix();
    glPopMatrix();
    
    glDisable(GL_LIGHT0);
    glPushMatrix();
        glTranslatef(0, 0.1, 0);
        glScaled(1, 0, 1);
        glColor3f(0, 0, 0);
        glTranslatef(x, y, z);
        
        //Middle Cloud
        glColor3f(1,1,1);
        glPushMatrix();
            glScalef(1.5, 1, 1);
            glutSolidSphere(1, 50,50);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(-1.9, 0, 0);
            glScalef(1, 0.8, 0.8);
            glutSolidSphere(1, 50,50);
        glPopMatrix();
        
        glPushMatrix();
            glTranslatef(1.9, 0, 0);
            glScalef(1, 0.8, 0.8);
            glutSolidSphere(1, 50,50);
        glPopMatrix();
    glPopMatrix();
    
    if(!ifSun){
        glDisable(GL_LIGHT0);
    }else{
        //printf("%f-%f\n",camX,camZ);
        glEnable(GL_LIGHT0);
    }
    
}

void drawTree(float x, float z){
    float matAmbAndDif1[] = {134.0/255, 68.0/255, 57.0/255, 1.0};
    float matAmbAndDif2[] = {100.0/255, 230.0/255, 150.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    
    
    glPushMatrix();
    glTranslatef(x, 0, z);
    //root
    glPushMatrix();
    glTranslatef(0,1.5,0);
    glScalef(.5, 3, .5);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif1);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glutSolidCube(1);
    glPopMatrix();
    
    //Leaves
    glPushMatrix();
    glTranslatef(0,3,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(1.5, 1.5, 20, 20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,4,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(1, 1.5, 20, 20);
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(0,5,0);
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, matAmbAndDif2);
    glMaterialfv(GL_FRONT, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT, GL_SHININESS, matShine);
    glRotatef(-90, 1, 0, 0);
    glutSolidCone(0.5, 1.5, 20, 20);
    glPopMatrix();
    
    glPopMatrix();
}

void drawBasketry(float x, float y, float z, float angle){
    float matAmbAndDifPole[] = {28.0/255, 26.0/255, 27.0/255, 1.0};
    float matAmbAndDifBoard[] = {229.0/255, 236.0/255, 242.0/255, 1.0};
    float matAmbAndDifBasketAndSquare[] = {232.0/255, 50.0/255, 45.0/255, 1.0};
    float matAmbAndDifNet[] = {203.0/255, 192.0/255, 189.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(angle, 0, 1, 0);
        
        //The pole
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifPole);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            //First Arm
            glPushMatrix();
                glTranslatef(0, 1.25, 0);
                glScalef(0.2, 2.5, 0.2);
                glutSolidCube(1);
            glPopMatrix();
    
            //Second Arm
            glPushMatrix();
                glTranslatef(0, 1.5, -0.17);
                glRotatef(30, 1, 0, 0);
                glTranslatef(0, 1, 0);
                glScalef(0.2, 1.5, 0.2);
                glutSolidCube(1);
            glPopMatrix();
        glPopMatrix();
    
        //The Board
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBoard);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
    
            glTranslatef(0, 3, 0.75);
            glScalef(2, 1.5, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        //The Red Square
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBasketAndSquare);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glColor3f(1,0,0);
            glTranslatef(0, 2.7, 0.76);
            glScalef(2/3.0, 0.5, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBoard);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);

            glTranslatef(0, 2.7, 0.77);
            glScalef(2/3.0 - 0.1, 0.5 - 0.1, 0.1);
            glutSolidCube(1);
        glPopMatrix();
    
        //The basket
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBasketAndSquare);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glColor3f(1,0,0);
            glTranslatef(0, 2.5, 1.12);
            glRotatef(90,1,0,0);
            glutSolidTorus(0.02, 0.35, 100, 100);
        glPopMatrix();
    
        //The net
        glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifNet);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
            glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
            glTranslatef(0, 2.5, 1.12);
            glRotatef(90, 1, 0, 0);
            gluCylinder(qobj, 0.35, 0.25, 0.3, 20, 10);
        glPopMatrix();
        
    glPopMatrix();
    
    
}

void drawStair(float x, float y, float z){
    glPushMatrix();
    glTranslatef(x,y,z);
        glPushMatrix();
            glTranslatef(0, 2.3, 1.3);
            glScalef(1.8,0.1,0.4);
            glutSolidCube(1);
        glPopMatrix();
    
        glPushMatrix();
            glTranslatef(0, 2.15, 1.55);
            glRotatef(90, 1, 0, 0);
            glScalef(1.8,0.1,0.4);
            glutSolidCube(1);
        glPopMatrix();
    glPopMatrix();
}

void drawSlide(float x, float y, float z){
    float matAmbAndDifSlide[] = {197.0/255, 9.0/255, 20.0/255, 1.0};
    float matAmbAndDifPole[] = {34.0/255, 217.0/255, 245.0/255, 1.0};
    float matAmbAndDifStairAndTop[] = {217.0/255, 165.0/255, 25.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(90, 0, 1, 0);
    
        //The Pole
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifPole);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);

        for(int i = -1; i<= 1; i+=2){
            for(int j = -1; j<= 1; j+=2){
                glPushMatrix();
                glTranslatef(i, 2, j);
                glScalef(0.2, 4, 0.2);
                glutSolidCube(1);
                glPopMatrix();
            }
        }
    
        //The Roof
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifStairAndTop);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 4, 0);
            glRotatef(90, -1, 0, 0);
            glutSolidCone(1.4, 0.8, 50, 50);
        glPopMatrix();
    
        //Floor
        glPushMatrix();
            glTranslatef(0, 2.3, 0);
            glScalef(2,0.2,2);
            glutSolidCube(1);
        glPopMatrix();
    
        //Stairs
        drawStair(0,0,0);
        drawStair(0,-0.4,0.5);
        drawStair(0,-0.8,1.0);
        drawStair(0,-1.2,1.5);
        drawStair(0,-1.6,2.0);
        drawStair(0,-2,2.5);
        drawStair(0,-2.4,3.0);
        
        //Slides
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifSlide);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 1.1, -3);
            glRotatef(-30, 1, 0, 0);
            glScalef(1.8,0.1,5);
            glutSolidCube(1);
        glPopMatrix();
            
    glPopMatrix();
}

void rotateBasketball(void){
    rotateAngle += 20;
    if(rotateAngle > 360.0) rotateAngle -= 360.0;
    glutPostRedisplay();
}

void drawBasketball(void){
    glPushMatrix();
    if(pickBasketball){
        if(shootBall){
            glTranslatef(basketballX + (movingBallZ + 1) * sin((180.0- ballAngle) * PI / 180) , basketballY + (-11.0/48)*movingBallZ*movingBallZ + (25.0/24)*movingBallZ - movingBallY, basketballZ - (movingBallZ + 1) * cos((180.0- ballAngle) * PI / 180) );
            glRotatef(rotateAngle,1,0,0);
        }
        else{
            glTranslatef(meX  , meY, meZ );
            glRotatef(angle -180, 0 , 1, 0);
            glTranslatef(0,0,-1);
        }
    }
    else{
        glTranslatef(24.5, 0.3, -12.5);
    }
    
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[2]);
    glShadeModel (GL_SMOOTH);
    glRotatef(rotateAngle + 90,1,0,0);
    glCallList(startList);
    glShadeModel (GL_FLAT);
    glDisable(GL_TEXTURE_2D);

    glPopMatrix();
}

void drawParkCarousel(float x, float y, float z){
    float matAmbAndDifBase[] = {200.0/255, 20.0/255, 30.0/255, 1.0};
    float matAmbAndDifHandler[] = {20.0/255, 247.0/255, 235.0/255, 1.0};
    float matAmbAndDifStairAndTop[] = {217.0/255, 165.0/255, 25.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    
    glPushMatrix();
        glTranslatef(x, y, z);
        glRotatef(parkCarouselAngle, 0, 1, 0);
    
        //The base
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifBase);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 0.1, 0);
            glScalef(1, 0.01, 1);
            glutSolidSphere(2.5, 50, 50);
        glPopMatrix();
    
        //Root Pole
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, matAmbAndDifHandler);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glTranslatef(0, 1, 0);
            glScalef(0.3, 2, 0.3);
            glutSolidCube(1);
        glPopMatrix();
    
        //Pole
    for(int i = 0; i <=360; i+=60){
        glPushMatrix();
        glRotatef(i, 0, 1, 0);
            glPushMatrix();
                glTranslatef(0, 1, 2.2);
                glScalef(0.3, 2, 0.3);
                glutSolidCube(1);
            glPopMatrix();
        
            glPushMatrix();
                glTranslatef(0, 1.85, 1.1);
                glScalef(0.3, 0.3, 1.9);
                glutSolidCube(1);
            glPopMatrix();
        glPopMatrix();
    }
       
    
    
    glPopMatrix();
}

void drawBees(float x, float y, float z){
    float bodyYellow[] = {242.0/255, 179.0/255, 28.0/255, 1.0};
    float bodyBlack[] = {1.0/255, 1.0/255, 4.0/255, 1.0};
    float wingColor[] = {187.0/255,215.0/255,237.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    
    glPushMatrix();
        //to the point where I want it to
        glTranslatef(x, y, z);
        glRotatef(beesAngle, 0, 1, 0);
        glTranslatef(0, 0, -2);

    
        
        //Main body
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, bodyYellow);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        glPushMatrix();
            glScalef(0.3, 0.2, 0.2);
            glutSolidSphere(1, 50, 50);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(-0.4, 0, 0);
            glScalef(0.2, 0.2, 0.2);
            glutSolidSphere(1, 50, 50);
        glPopMatrix();
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, bodyBlack);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        //Nose
        glPushMatrix();
            glTranslatef(-0.6, 0, 0);
            glScalef(0.05, 0.05, 0.05);
            glutSolidSphere(1, 50, 50);
        glPopMatrix();
        //Eyes
        glPushMatrix();
            glTranslatef(-0.6, 0.1, -0.08);
            glScalef(0.04, 0.04, 0.04);
            glutSolidSphere(1, 50, 50);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(-0.6, 0.1, 0.08);
            glScalef(0.04, 0.04, 0.04);
            glutSolidSphere(1, 50, 50);
        glPopMatrix();
        glPushMatrix();
        glTranslatef(0.1, 0, 0);
            glRotatef(90, 0, 1, 0);
            glScalef(1, 1, 3);
            glutSolidTorus(0.01, 0.2, 50, 50);
        glPopMatrix();
        glPushMatrix();
        glTranslatef(-0.1, 0, 0);
            glRotatef(90, 0, 1, 0);
            glScalef(1, 1, 3);
            glutSolidTorus(0.01, 0.2, 50, 50);
        glPopMatrix();
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, wingColor);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
        //Left wing
        glPushMatrix();
        glRotatef(wingsAngle, 1, 0, 0);
        glTranslatef(0, 0, 0.5);
        glScaled(0.3, 0, 0.3);
        glutSolidSphere(1, 20, 20);
        glPopMatrix();
        //Right Wind
        glPushMatrix();
        glRotatef(-wingsAngle, 1, 0, 0);
        glTranslatef(0, 0, -0.5);
        glScaled(0.3, 0, 0.3),
        glutSolidSphere(1, 20, 20);
        glPopMatrix();
    glPopMatrix();
}

void drawWords(){
    float words[] = {0.0/255, 0.0/255, 0.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {10.0};
    
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, words);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, words);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
    glPushMatrix();
    glTranslatef(meX - 2 , meY-1.5, meZ-1.5 );
    glTranslatef(2, 1.5, 1.5);
    glRotatef(angle - 180 , 0, 1, 0);
    glTranslatef(-2, -1.5, -1.5);
    char c = pointsCount;
    char divide[] = "WelCome to the Park!";
    glScalef(0.003, 0.003, 0.003);
    writeStrokeString(GLUT_STROKE_ROMAN, divide);

    glPopMatrix();
}

void rainDisplay(){
    float rain[] = {34.0/255, 201.0/255, 255.0/255, 1.0};
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    int i;
    
    glDisable(GL_TEXTURE_2D);
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, rain);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, matShine);
    
    if(ifRain){
        for(i=0; i<num_particles; i++)
        {
            glPushMatrix();
            glColor3fv(colors[particles[i].color]);
            glColor3fv(colors[0]);
            glTranslatef(particles[i].position[0],particles[i].position[1],particles[i].position[2]);
            
            if(rainShape == 1){
                glScalef(0.01, 0.1, 0.01);
                glutSolidCube(4);
            }
            else if(rainShape == 2) glutSolidSphere(0.3, 50, 50);
            glPopMatrix();
        }
    }
    
}



void drawScene(void){
    // *********  x11Fix begin chunk
    glutSetWindow(main_window);
    if(scenex11WorkAround)
    {
        glutReshapeWindow(width-1,height-1);// Has to be different dimensions than in glutInitWindowSize();
        scenex11WorkAround = false;
    }
    //*********** x11Fix end chunk
    
    // Material property vectors.
    float lightPos0[] = { 0,0,0, 1.0 };
//    float lightPos1[] = { meX , meY - 1, meZ - 1, 1.0 };
//    float matAmbAndDif1[] = {191.0/255, 177.0/255,
    
    float matSpec[] = {1.0, 1.0, 1.0, 1.0};
    float matShine[] = {50.0};
    float matShine1[] = {1.0};
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, t);
//    glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, t);
    
    //Set Projection
    setProjection();
    
    //Clear Modeview Matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    lookAt();
    glDisable(GL_LIGHTING);
    
    // make a sun
    glDisable(GL_LIGHTING);
    
    glLightfv(GL_LIGHT0, GL_SPECULAR, matSpec);
    glLightfv(GL_LIGHT0, GL_SHININESS, matShine1);

    if(!ifSun){
        glDisable(GL_LIGHT0);
    }else{
        //printf("%f-%f\n",camX,camZ);
        glEnable(GL_LIGHT0);
    }
    glPushMatrix();
    glTranslatef(27, 11, -15);
    glColor3f(1.0, 1.0, 1.0);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);
    glutSolidSphere(2, 8, 8);
    glPopMatrix();
    glEnable(GL_LIGHTING);
    
    if(ifWelcome) drawWords();
    
    drawCloud(cloud1, 7.5, -3);
    drawCloud(cloud2, 7.5, -5);
    drawCloud(cloud3, 7.5, -7);
    drawCloud(cloud4, 7.5, -9);
    drawCloud(cloud5, 7.5, -11);
    drawCloud(cloud6, 7.5, -15);
    drawCloud(cloud7, 7.5, -18);

    //Draw the ground
    drawGround();
    drawCourt();
        
    drawTable(26, 0, -2);
    drawTable(22, 0, -4);
    drawTable(24, 0, -6);
    
    drawBasketry(24.5, 0, -17, 0);
    drawBasketry(24.5, 0, -8, 180);
    
    //Draww trees
    for(int i = -1.5 ; i >= -20; i-=3){
        drawTree(28.5,i);
    }
    for(int i = -1.5 ; i >= -20; i-=3){
        drawTree(1.5,i);
    }
    for(int i = 4.5 ; i <= 25.5; i+=3){
        drawTree(i,-18.5);
    }
    
    drawBasketball();
    drawSlide(10,0,-15);
    drawParkCarousel(8, 0, -9);
    drawBees(15, 2.1, -4);
    rainDisplay();
    if(selecting) getID(xClick, yClick);
    glutSwapBuffers();
}

void resizeDisplayWindow(int w, int h)
{
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 500, 0, 500, -200, 200);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
}

void drawSceneDisplayWindow(void){
    //choose window
    glutSetWindow(display_window);
    if(displayx11WorkAround)
    {
        glutReshapeWindow(width-1,height-1);// Has to be different dimensions than in glutInitWindowSize();
        displayx11WorkAround = false;
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glColor3f(1,1,1);
    glRasterPos3f(200,300,0);
    writeBitmapString((void*)font, "Final Project");
    
    glColor3f(1,1,1);
    glRasterPos3f(220,270,0);
    writeBitmapString((void*)font, "Runzhi Ma");
  
    glDisable(GL_DEPTH_TEST);
    glutSwapBuffers();
}

static float shootingStage = 0;

void animate(int f){
    //篮球投射
    if(shootBall && movingBallZ < 4){
        movingBallZ += 0.1;
    }
    
    if((movingBallZ > 4 && movingBallZ < 4.1 )
       && (basketballX  > 24.15 && basketballX  < 24.85)
       && (
           (basketballZ  > -14.5 && basketballZ  < -14)
            || (basketballZ > -11.5 && basketballZ < -11)
           )&& (basketballY > 0.2)){
        movingBallY += 0.1;

    }
    else if((movingBallZ > 4 && movingBallZ < 4.1 )){
        printf("Try it again!\n");
        ballAngle = 0;
        movingBallZ = 0;
        movingBallY = 0;
        shootBall = false;
    }

    if(movingBallY >= 2.3){
        pointsCount += 1;
        printf("Bingo!\n");
        ballAngle = 0;
        movingBallZ = 0;
        movingBallY = 0;
        shootBall = false;
    }
    
    if(ifParkCarouse) parkCarouselAngle +=1;
    
    if(cloudMove){
        if(cloud1 < 30) cloud1 +=0.1;
        if(cloud1 >= 30) cloud1 = 0;
        if(cloud2 < 30) cloud2 +=0.1;
        if(cloud2 >= 30) cloud2 = 0;
        if(cloud3 < 30) cloud3 +=0.1;
        if(cloud3 >= 30) cloud3 = 0;
        if(cloud4 < 30) cloud4 +=0.1;
        if(cloud4 >= 30) cloud4 = 0;
        if(cloud5 < 30) cloud5 +=0.1;
        if(cloud5 >= 30) cloud5 = 0;
        if(cloud6 < 30) cloud6 +=0.1;
        if(cloud6 >= 30) cloud6 = 0;
        if(cloud7 < 30) cloud7 +=0.1;
        if(cloud7 >= 30) cloud7 = 0;
        
    }
    
    if(beessFly){
        beesAngle += 1;
        wingsAngle +=5;
    }
    
    for(int i=0; i<num_particles; i++)
    {

        if(particles[i].position[1] < 0){
            particles[i].position[1] = 11;
        }
        else{
            particles[i].position[1] -= .5;
        }
    }
    
    glutPostRedisplay();
    glutTimerFunc(20, animate, 0);
}


void keyInput(unsigned char key, int x, int y)
{
   switch(key)
   {
       case 27:
           exit(0);
           break;
       case '0':
           view = 0;
           glutPostRedisplay();
           break;
       case'1':
           view = 1;
           glutPostRedisplay();
           break;
       case'2':
           view = 2;
           glutPostRedisplay();
           break;
       case'3':
           view = 3;
           glutPostRedisplay();
           break;
       case'4':
           view = 4;
           glutPostRedisplay();
           break;
       case'5':
           view = 5;
           glutPostRedisplay();
           break;
       case '+':
           lookUp +=.2;
           glutPostRedisplay();
           break;
       case '-':
           lookUp -=.2;
           glutPostRedisplay();
           break;
       case's':
           ifSun = !ifSun;
           glutPostRedisplay();
           break;
       case'p':
           pickBasketball = !pickBasketball;
           if(pickBasketball) glutIdleFunc(rotateBasketball);
           else           glutIdleFunc(NULL);
           glutPostRedisplay();
           glutPostRedisplay();
           break;
       case'f':
           basketballX = meX;
           basketballY = meY;
           basketballZ = meZ;
           ballAngle = angle;
           shootBall = !shootBall;
           break;
       case'c':
           ifParkCarouse = !ifParkCarouse;
           glutPostRedisplay();
           break;
       case'm':
           cloudMove = !cloudMove;
           glutPostRedisplay();
           break;
       case'b':
           beessFly = !beessFly;
           glutPostRedisplay();
           break;
       case'w':
           ifWelcome = !ifWelcome;
           glutPostRedisplay();
           break;
       case'r':
           ifRain = !ifRain;
           glutPostRedisplay();
           break;
       case'h':
           rainShape = 1;
           glutPostRedisplay();
           break;
       case'j':
           rainShape = 2;
           glutPostRedisplay();
           break;
   }
}

void specialKeyInput(int key, int x, int y)
{
    switch(key){
        case GLUT_KEY_UP: //forward
            meZ += stepsize * cos(angle * PI / 180)/2;
            meX += stepsize * sin(angle * PI / 180)/2;
            break;
        case GLUT_KEY_DOWN: //back
            meZ -= stepsize * cos(angle * PI / 180)/2;
            meX -= stepsize * sin(angle * PI / 180)/2;
            break;
        case GLUT_KEY_RIGHT: //turn right
            angle -= turnsize;
            break;
        case GLUT_KEY_LEFT: //turn left
            angle += turnsize;
            break;
    }//end switch
    glutPostRedisplay();
}

void time_menu(int id){
    if(id == 2) ifSun = true;
    if(id == 3) ifSun = false;
    glutPostRedisplay();
}

void look_at_menu(int id){
    if(id == 4) view = 1;
    if(id == 5) view = 2;
    if(id == 6) view = 3;
    if(id == 7) view = 4;
    if(id == 8) view = 0;
    if(id == 9) view = 5;
    glutPostRedisplay();
}

void view_menu(int id){
    if(id == 10) lookUp += .2;
    if(id == 11) lookUp -= .2;
    glutPostRedisplay();
}

void basketball_menu(int id){
    if(id == 14){
        pickBasketball = true;
        if(pickBasketball) glutIdleFunc(rotateBasketball);
        else           glutIdleFunc(NULL);
    }
    if(id == 15){
        pickBasketball = false;
        if(pickBasketball) glutIdleFunc(rotateBasketball);
        else           glutIdleFunc(NULL);
    }
    if(id == 16) {
        basketballX = meX;
        basketballY = meY;
        basketballZ = meZ;
        ballAngle = angle;
        shootBall = !shootBall;
    }
    glutPostRedisplay();
}

void rain_menu(int id){
    if(id == 21) ifRain = true;
    if(id == 22) ifRain = false;
    if(id == 23) rainShape = 1;
    if(id == 24) rainShape = 2;
    
    glutPostRedisplay();
}

void menu(int id){
    if(id == 1) exit(0);
    if(id == 17) ifParkCarouse = !ifParkCarouse;
    if(id == 18) beessFly = !beessFly;
    if(id == 19) cloudMove = !cloudMove;
    if(id == 20) ifWelcome = !ifWelcome;

    glutPostRedisplay();
}

void makeMenu(void){
    int sub1_menu = glutCreateMenu(time_menu);
    glutAddMenuEntry("Day", 2);
    glutAddMenuEntry("Night", 3);
    
    int sub2_menu = glutCreateMenu(look_at_menu);
    glutAddMenuEntry("From North", 4);
    glutAddMenuEntry("From South", 5);
    glutAddMenuEntry("From West", 6);
    glutAddMenuEntry("From East", 7);
    glutAddMenuEntry("From Top", 8);
    glutAddMenuEntry("First Perspective", 9);
    
    int sub3_menu = glutCreateMenu(view_menu);
    glutAddMenuEntry("Look up", 10);
    glutAddMenuEntry("Loop down", 11);
    
    int sub4_menu = glutCreateMenu(basketball_menu);
    glutAddMenuEntry("Pick", 14);
    glutAddMenuEntry("Unpick", 15);
    glutAddMenuEntry("Shoot", 16);
    
    int sub5_menu = glutCreateMenu(rain_menu);
    glutAddMenuEntry("On", 21);
    glutAddMenuEntry("Off", 22);
    glutAddMenuEntry("rain", 23);
    glutAddMenuEntry("snow", 24);

    glutCreateMenu(menu);
    glutAddMenuEntry("Quit", 1);
    glutAddSubMenu("Time", sub1_menu);
    glutAddSubMenu("Perspective", sub2_menu);
    glutAddSubMenu("View", sub3_menu);
    glutAddSubMenu("Basketball", sub4_menu);
    glutAddMenuEntry("Park Carouse", 17);
    glutAddMenuEntry("Bee", 18);
    glutAddMenuEntry("Cloud", 19);
    glutAddMenuEntry("Welcome Words", 20);
    glutAddSubMenu("Rain", sub5_menu);
    
    glutAttachMenu(GLUT_RIGHT_BUTTON);
    
}


int main(int argc, char **argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    
    main_window = glutCreateWindow("Park");
    setup();
    myinit ();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyInput);
    glutMouseFunc(mouseControl);
    glutSpecialFunc(specialKeyInput);
    glutTimerFunc(20, animate, 0);
    makeMenu();
    
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(600, 100);
    display_window = glutCreateWindow("Info");
    setupDisplayWindow();
    glutDisplayFunc(drawSceneDisplayWindow);
    glutReshapeFunc(resizeDisplayWindow);
    
    glutMainLoop();
    return 0;
}
