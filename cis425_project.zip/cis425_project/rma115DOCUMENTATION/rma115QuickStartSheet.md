* Official Name: Runzhi Ma

* Call me: Runzhi

* E-mail: rma115@syr.edu

* Assignment: final project

* Environment/Compiler: Xcode Version 13.2.1 (13C100)

* Date submitted: April 28, 2022

* References: I have use some functions like printing string, import texture from professor's code from the class.

* Interactions:

  * Press esc to quit.

  * Press 0 to view from the top.

  * Press 1 to view from the north

  * Press 2 to view from the south

  * Press 3 to view from the west

  * Press 4 to view from the east

  * Press 5 to view from the first person view

  * Press s to activate of deactivate the sun

  * Press p to shoot the basketball

  * Press c to make the park carouse move or stop

  * Press m to make the cloud move or stop

  * Press b to make the bee move or stop

  * Press w to activate the welcome words or deactivate it

  * Press + to choose look up

  * Press - to choose look down

  * Press r to start or stop the rain

  * Press h to rain

  * Press j to snow

  * Press GLUT_KEY_UP to move forward

  * Press GLUT_KEY_DOWN to move backward

  *         Press GLUT_KEY_RIGHT to turn right


  *         Press GLUT_KEY_LEFT to turn left


  *         Right button to activate the menu; In the menu, you can almost all the thing you can do same as using keyboard

